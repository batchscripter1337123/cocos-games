hi hope you enjoy play my palm simulator
i added crash button so if smth error or smth you can click it

cocos