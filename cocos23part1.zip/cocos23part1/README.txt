hi thanks for downloading the cocos i worked on it but well it doesnt really work good so
i dont really know what to say but uhh i guess my game is kinda not good
i made it with windows forms so i think you need to have windows forms or smth
i posted it on github and googl drive as you can see

sugggestions or/and suggestions to cblphiki gmail com

Sincerely batchscripter1337123