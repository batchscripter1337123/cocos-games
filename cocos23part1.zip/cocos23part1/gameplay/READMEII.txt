this is not very working feature but its in test

#set sets the variable (if it exists)

game checks 5 time a second so viruswait 15 is once in 3 seconds

kerbals is how much time it takes to drain 1 water (15 is once in 3 second)
each water tile contains 2 water

batchscripter1337123